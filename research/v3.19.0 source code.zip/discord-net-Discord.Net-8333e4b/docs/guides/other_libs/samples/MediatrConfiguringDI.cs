.AddMediatR(typeof(Bot))
