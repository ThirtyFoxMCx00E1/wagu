
#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <android/log.h>
#include "amlmod.h"

#define TAG "ScreenGuard"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#define FLAG_SECURE 0x00002000   

MYMOD(net.screenguard.gtasa, ScreenGuard, 1.0, Paltriz)

typedef jint (*GetCreatedJavaVMs_t)(JavaVM**, jsize, jsize*);

static JavaVM* g_vm = nullptr;

static JavaVM* FindJavaVM()
{
    static const char* libs[] = { nullptr, "libnativehelper.so", "libart.so" };
    for (const char* name : libs)
    {
        void* h = name ? dlopen(name, RTLD_NOW) : RTLD_DEFAULT;
        if (!h) continue;
        auto fn = (GetCreatedJavaVMs_t)dlsym(h, "JNI_GetCreatedJavaVMs");
        if (!fn) continue;
        JavaVM* vm = nullptr; jsize n = 0;
        if (fn(&vm, 1, &n) == JNI_OK && n > 0 && vm) return vm;
    }
    return nullptr;
}

static void ClearEx(JNIEnv* env)
{
    if (env->ExceptionCheck()) { env->ExceptionClear(); }
}


static int ApplySecureFlag(JNIEnv* env)
{
    int patched = 0;

    jclass atCls = env->FindClass("android/app/ActivityThread");
    if (!atCls) { ClearEx(env); return 0; }

    jmethodID cur = env->GetStaticMethodID(atCls, "currentActivityThread", "()Landroid/app/ActivityThread;");
    if (!cur) { ClearEx(env); return 0; }
    jobject at = env->CallStaticObjectMethod(atCls, cur);
    if (!at) { ClearEx(env); return 0; }

    jfieldID fActs = env->GetFieldID(atCls, "mActivities", "Landroid/util/ArrayMap;");
    if (!fActs) { ClearEx(env); return 0; }
    jobject map = env->GetObjectField(at, fActs);
    if (!map) return 0;

    jclass mapCls = env->FindClass("android/util/ArrayMap");
    jmethodID mSize = env->GetMethodID(mapCls, "size", "()I");
    jmethodID mVal  = env->GetMethodID(mapCls, "valueAt", "(I)Ljava/lang/Object;");
    if (!mSize || !mVal) { ClearEx(env); return 0; }

    jclass recCls = env->FindClass("android/app/ActivityThread$ActivityClientRecord");
    jfieldID fAct = recCls ? env->GetFieldID(recCls, "activity", "Landroid/app/Activity;") : nullptr;
    if (!fAct) { ClearEx(env); return 0; }

    jclass actCls = env->FindClass("android/app/Activity");
    jmethodID mWin = env->GetMethodID(actCls, "getWindow", "()Landroid/view/Window;");
    jclass winCls = env->FindClass("android/view/Window");
    jmethodID mAdd = env->GetMethodID(winCls, "addFlags", "(I)V");
    if (!mWin || !mAdd) { ClearEx(env); return 0; }

    jint n = env->CallIntMethod(map, mSize);
    for (jint i = 0; i < n; i++)
    {
        jobject rec = env->CallObjectMethod(map, mVal, i);
        if (!rec) continue;
        jobject act = env->GetObjectField(rec, fAct);
        if (act)
        {
            jobject win = env->CallObjectMethod(act, mWin);
            if (win)
            {
                env->CallVoidMethod(win, mAdd, (jint)FLAG_SECURE);
                if (env->ExceptionCheck()) { env->ExceptionClear(); LOGE("addFlags threw"); }
                else patched++;
                env->DeleteLocalRef(win);
            }
            else ClearEx(env);
            env->DeleteLocalRef(act);
        }
        env->DeleteLocalRef(rec);
    }
    return patched;
}

static void* GuardThread(void*)
{
    JNIEnv* env = nullptr;
    if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) { LOGE("attach failed"); return nullptr; }

    bool logged = false;
    for (;;)
    {
    
        int n = ApplySecureFlag(env);
        if (n > 0 && !logged) { LOGI("FLAG_SECURE applied to %d activity window(s)", n); logged = true; }
        usleep(1500 * 1000);
    }
    return nullptr;
}

extern "C" void OnModLoad()
{
    g_vm = FindJavaVM();
    if (!g_vm) { LOGE("JavaVM not found - plugin inactive"); return; }

    pthread_t t;
    pthread_create(&t, nullptr, GuardThread, nullptr);
    pthread_detach(t);
    LOGI("ScreenGuard loaded");
}
