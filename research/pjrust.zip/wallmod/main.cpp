#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <aml-psdk/game_sa/engine/World.h>

#include <cmath>
#include <deque>

#include "psdk_extern.h"
#include "WallButton.h"
#include <isautils.h>
#include <aml-psdk/game_sa/engine/ModelInfo.h>

MYMODCFG(net.tornamic.wallbutton, Wall Button, 1.0.0, Tornamic)
NEEDGAME(com.rockstargames.gtasa)
BEGIN_DEPLIST()
    ADD_DEPENDENCY_VER(net.rusjj.gtasa.utils, 1.6)
END_DEPLIST()

namespace {
constexpr int kWallModel = 1980;          
ISAUtils* saUtils = nullptr;
ConfigEntry* segmentCount = nullptr;      
ConfigEntry* segmentSpacing = nullptr;  
ConfigEntry* placementDistance = nullptr;      
ConfigEntry* maxWallCount = nullptr;      
ConfigEntry* wallWidth = nullptr;     
ConfigEntry* wallHeight = nullptr;
ConfigEntry* wallThickness = nullptr;
ConfigEntry* rotationOffset = nullptr;     
ConfigEntry* groundOffset = nullptr;       

std::deque<int> wallHandles;          

void deleteObjectHandle(int handle) {
    static const SCRIPT_COMMAND kDeleteObject = {0x0108, "i"};
    saUtils->ScriptCommand(&kDeleteObject, handle);
}

void clearPlacedWalls() {
    if (!saUtils) return;
    for (int h : wallHandles) deleteObjectHandle(h);
    wallHandles.clear();
}

bool calculateWallPlacement(float& px, float& py, float& pz, float& fx, float& fy, float& rx, float& ry) {
    CPlayerPed* player = FindPlayerPed(-1);
    if (!player || !player->m_matrix) return false;

    const CVector pos = player->GetPosition();
    CVector fwd = player->GetTopDirection();
    CVector right = player->GetRightDirection();
    const float fl = std::sqrt(fwd.x * fwd.x + fwd.y * fwd.y);
    const float rl = std::sqrt(right.x * right.x + right.y * right.y);
    if (fl < 0.001f || rl < 0.001f) return false;
    fx = fwd.x / fl;  fy = fwd.y / fl;
    rx = right.x / rl; ry = right.y / rl;

    const float dist = placementDistance->GetFloat();
    px = pos.x + fx * dist;
    py = pos.y + fy * dist;
    float z = CWorld::FindGroundZForCoord(px, py);
    if (z < -50.0f) z = pos.z - 1.0f;
    pz = z;
    return true;
}

struct WallDims {
    float halfLong, halfShort, halfH;   
    float zMin;                         
    float cxl, cyl;                     
    bool  longIsY;                      
    bool  fromModel;
};

WallDims getWallDimensions() {
    WallDims d{};
    d.halfLong  = wallWidth->GetFloat() * 0.5f;
    d.halfShort = wallThickness->GetFloat() * 0.5f;
    d.halfH     = wallHeight->GetFloat() * 0.5f;
    d.zMin      = -groundOffset->GetFloat();   
    d.cxl = d.cyl = 0.0f;
    d.longIsY = false;
    d.fromModel = false;

    CBaseModelInfo* mi = CModelInfo::ms_modelInfoPtrs[kWallModel];
    if (!mi || !mi->m_pColModel) return d;   
    const CBox& bb = mi->m_pColModel->m_boundBox;
    const float dx = bb.m_vecMax.x - bb.m_vecMin.x;
    const float dy = bb.m_vecMax.y - bb.m_vecMin.y;
    const float dz = bb.m_vecMax.z - bb.m_vecMin.z;
    if (dx < 0.05f || dy < 0.05f || dz < 0.05f || dx > 200.0f || dy > 200.0f || dz > 200.0f) return d;

    d.longIsY   = dy > dx;
    d.halfLong  = (d.longIsY ? dy : dx) * 0.5f;
    d.halfShort = (d.longIsY ? dx : dy) * 0.5f;
    d.halfH     = dz * 0.5f;
    d.zMin      = bb.m_vecMin.z;
    d.cxl       = (bb.m_vecMin.x + bb.m_vecMax.x) * 0.5f;
    d.cyl       = (bb.m_vecMin.y + bb.m_vecMax.y) * 0.5f;
    d.fromModel = true;
    return d;
}

float getWallHeadingRadians(const WallDims& d, float fx, float fy, float rx, float ry) {
    return d.longIsY ? std::atan2(-rx, ry) : std::atan2(-fx, fy);
}

bool wallModelRequested = false;

void updateWallPreview() {
    float px, py, pz, fx, fy, rx, ry;
    if (!calculateWallPlacement(px, py, pz, fx, fy, rx, ry)) { SetWallGhost(nullptr); return; }

    if (!wallModelRequested) {            
        saUtils->LoadModelId(kWallModel);
        wallModelRequested = true;
    }
    const WallDims d = getWallDimensions();

    WallGhost g{};
    g.cx = px; g.cy = py; g.cz = pz + d.halfH;    
    g.rx = rx; g.ry = ry;
    g.nx = fx; g.ny = fy;
    g.halfW = d.halfLong;
    g.halfH = d.halfH;
    g.halfT = d.halfShort;
    SetWallGhost(&g);
}

void createWall() {
    float px, py, pz, fx, fy, rx, ry;
    if (!calculateWallPlacement(px, py, pz, fx, fy, rx, ry)) return;

    const int model = kWallModel;
    saUtils->LoadModelId(model);
    const WallDims d = getWallDimensions();

    const float headingRad = getWallHeadingRadians(d, fx, fy, rx, ry);
    const float heading = headingRad * 57.29577951f + rotationOffset->GetFloat();
    const float hr = heading * 0.01745329252f;

    const float ox = d.cxl * std::cos(hr) - d.cyl * std::sin(hr);
    const float oy = d.cxl * std::sin(hr) + d.cyl * std::cos(hr);
    const float x = px - ox;
    const float y = py - oy;
    float gz = CWorld::FindGroundZForCoord(px, py);
    if (gz < -50.0f) gz = pz;
    const float z = gz - d.zMin;        

    static const SCRIPT_COMMAND kSetHeading   = {0x0177, "if"};
    static const SCRIPT_COMMAND kSetCollision = {0x0382, "ii"};
    static const SCRIPT_COMMAND kSetDynamic   = {0x0392, "ii"};

    int handle = -1;
    CObject* obj = saUtils->CreateObject(model, x, y, z, &handle);
    if (!obj || handle < 0) {
        logger->Error("Wall Button: CreateObject failed for model %d", model);
    } else {
        saUtils->ScriptCommand(&kSetHeading, handle, heading);
        saUtils->ScriptCommand(&kSetCollision, handle, 1);
        saUtils->ScriptCommand(&kSetDynamic, handle, 0);   
        wallHandles.push_back(handle);
    }
    saUtils->MarkModelAsNotNeeded(model);

    const size_t cap = maxWallCount->GetInt() < 1 ? 1 : (size_t)maxWallCount->GetInt();
    while (wallHandles.size() > cap) {
        deleteObjectHandle(wallHandles.front());
        wallHandles.pop_front();
    }
    logger->Info("Wall Button: model %d, size %.2f x %.2f x %.2f (%s), heading %.1f",
                 model, d.halfLong * 2, d.halfShort * 2, d.halfH * 2,
                 d.fromModel ? "from model" : "from config", heading);
}

ON_MOD_LOAD() {
    logger->SetTag("Wall Button");
    segmentCount     = cfg->Bind("Segments", 1);
    segmentSpacing = cfg->Bind("SegmentWidth", 4.0f);
    placementDistance     = cfg->Bind("Distance", 3.0f);
    maxWallCount     = cfg->Bind("MaxPieces", 30);
    wallWidth    = cfg->Bind("WallWidth", 4.0f);
    wallHeight   = cfg->Bind("WallHeight", 3.0f);
    wallThickness    = cfg->Bind("WallThickness", 0.25f);
    groundOffset      = cfg->Bind("ZOffset", 0.0f);
    rotationOffset    = cfg->Bind("RotationOffset", 0.0f);

    saUtils = (ISAUtils*)(GetInterface("SAUtils"));
    if (!saUtils) {
        logger->Error("SAUtils 1.6 is required; Wall Button disabled");
        return;
    }
    const uintptr_t game = aml->GetLib("libGTASA.so");
    if (!game) {
        logger->Error("libGTASA.so is not loaded; Wall Button disabled");
        return;
    }
    InitWallButton(game);
    logger->Info("Wall Button: 3D button initialized");
}

ON_ALL_MODS_LOAD() {
    Events::gameProcessEvent += []() {
        if (!saUtils || !saUtils->IsGameInitialised()) return;
        UpdateWallButton();
        if (!IsWallPreviewActive()) wallModelRequested = false;
        if (IsWallPreviewActive()) updateWallPreview();   
        if (WasWallConfirmed()) { SetWallGhost(nullptr); createWall(); }
        if (WasWallCancelled()) SetWallGhost(nullptr);
    };
    Events::drawHudEvent += []() { DrawWallButton(); };
}

ON_MOD_UNLOAD() {
    clearPlacedWalls();
    delete segmentCount; delete segmentSpacing;
    delete placementDistance; delete maxWallCount;
    delete rotationOffset; delete wallWidth; delete wallHeight; delete wallThickness; delete groundOffset;
}
