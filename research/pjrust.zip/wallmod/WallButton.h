#pragma once
#include <cstdint>

struct WallGhost {
    float cx, cy, cz;      
    float rx, ry;          
    float nx, ny;          
    float halfW, halfH, halfT;
};

void InitWallButton(uintptr_t gameBase);

void UpdateWallButton();

void DrawWallButton();

bool IsWallPreviewActive();
void SetWallPreviewActive(bool active);
void SetWallGhost(const WallGhost* ghost);   

bool WasWallConfirmed();
bool WasWallCancelled();
