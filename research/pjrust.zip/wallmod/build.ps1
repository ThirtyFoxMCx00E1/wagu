param(
    [string]$NDKPath = $env:ANDROID_NDK_HOME
)

if (-not $NDKPath) { throw "Set ANDROID_NDK_HOME or pass -NDKPath" }
$buildScript = Join-Path $NDKPath "build/ndk-build"
if (-not ($PSVersionTable.PSEdition -eq "Core")) { $buildScript += ".cmd" }
& $buildScript NDK_PROJECT_PATH=$PSScriptRoot APP_BUILD_SCRIPT=$PSScriptRoot/Android.mk NDK_APPLICATION_MK=$PSScriptRoot/Application.mk NDK_DEBUG=0
exit $LASTEXITCODE
