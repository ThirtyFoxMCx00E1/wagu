#include "WallButton.h"

#include <chrono>
#include <cmath>

#include <aml-psdk/game_sa/entity/Ped.h>
#include <aml-psdk/game_sa/entity/PlayerPed.h>
#include <aml-psdk/game_sa/engine/Sprite.h>
#include <aml-psdk/game_sa/engine/RsGlobal.h>
#include <aml-psdk/game_sa/entity/Placeable.h>
#include <aml-psdk/gta_base/Vector.h>
#include <aml-psdk/gta_base/drawRect.h>
#include <aml-psdk/gta_base/RGBA.h>

using IsTouchDown_t = bool (*)(int);
using GetTouchPosition_t = void (*)(CVector2D*, int);
using GetNumTouches_t = int (*)();
using CSprite2d_DrawRect_t = void (*)(const CRect&, const CRGBA&);
using CSprite2d_Draw2DPolygon_t = void (*)(float, float, float, float,
                                            float, float, float, float,
                                            const CRGBA&);

static IsTouchDown_t IsTouchDown = nullptr;
static GetTouchPosition_t GetTouchPosition = nullptr;
static GetNumTouches_t GetNumTouches = nullptr;
static CSprite2d_DrawRect_t DrawRectFn = nullptr;
static CSprite2d_Draw2DPolygon_t DrawPolyFn = nullptr;

static constexpr uintptr_t IS_TOUCH_DOWN_OFFSET     = 0x002B0A38;
static constexpr uintptr_t GET_TOUCH_POSITION_OFFSET = 0x002B0A54;
static constexpr uintptr_t GET_NUM_TOUCHES_OFFSET   = 0x002B0A70;
static constexpr uintptr_t DRAW_RECT_OFFSET         = 0x005CA1E4;
static constexpr uintptr_t DRAW_2D_POLYGON_OFFSET   = 0x005C9DF8;

static constexpr float BUTTON_W = 86.0f;
static constexpr float BUTTON_H = 76.0f;
static constexpr float COOLDOWN_SECONDS = 0.6f;

static CRect buttonBounds{};
static bool buttonVisible = false;
static bool wasButtonTouched = false;
static bool buttonInitialized = false;

static bool previewActive = false;
static bool previewConfirmed = false;
static bool previewCancelled = false;
static bool hasWallPreview = false;
static WallGhost wallPreview{};
static CRect confirmBounds{}, cancelBounds{};
static bool wasConfirmTouched = false, wasCancelTouched = false;
static bool previewOpenedThisFrame = false;
static std::chrono::steady_clock::time_point lastButtonTap;

static void drawRect(float l, float t, float r, float b, const CRGBA& c)
{
    if (!DrawRectFn) return;
    CRect rc{l, t, r, b};
    DrawRectFn(rc, c);
}

static void drawOctagon(float cx, float cy, float size, const CRGBA& c)
{
    if (!DrawRectFn || !DrawPolyFn) return;
    const float h = size * 0.5f, cut = size * 0.20f;
    drawRect(cx - h + cut, cy - h, cx + h - cut, cy + h, c);
    drawRect(cx - h, cy - h + cut, cx + h, cy + h - cut, c);
    DrawPolyFn(cx - h + cut, cy - h, cx - h, cy - h + cut,
               cx - h, cy + h - cut, cx - h + cut, cy + h, c);
    DrawPolyFn(cx + h - cut, cy - h, cx + h, cy - h + cut,
               cx + h, cy + h - cut, cx + h - cut, cy + h, c);
}

static void drawBrickIcon(float cx, float cy, float s, const CRGBA& c)
{
    const float w = s, h = s * 0.72f;
    const float left = cx - w * 0.5f, top = cy - h * 0.5f;
    const float rowH = h / 3.0f, gap = 2.0f;
    for (int row = 0; row < 3; ++row)
    {
        const float y0 = top + row * rowH + gap * 0.5f;
        const float y1 = top + (row + 1) * rowH - gap * 0.5f;
        if (row == 1)
        {
            drawRect(left, y0, left + w * 0.25f - gap * 0.5f, y1, c);
            drawRect(left + w * 0.25f + gap * 0.5f, y0, left + w * 0.75f - gap * 0.5f, y1, c);
            drawRect(left + w * 0.75f + gap * 0.5f, y0, left + w, y1, c);
        }
        else
        {
            drawRect(left, y0, left + w * 0.5f - gap * 0.5f, y1, c);
            drawRect(left + w * 0.5f + gap * 0.5f, y0, left + w, y1, c);
        }
    }
}

void InitWallButton(uintptr_t gameBase)
{
    if (!gameBase) return;
    IsTouchDown = reinterpret_cast<IsTouchDown_t>(gameBase + IS_TOUCH_DOWN_OFFSET + 1);
    GetTouchPosition = reinterpret_cast<GetTouchPosition_t>(gameBase + GET_TOUCH_POSITION_OFFSET + 1);
    GetNumTouches = reinterpret_cast<GetNumTouches_t>(gameBase + GET_NUM_TOUCHES_OFFSET + 1);
    DrawRectFn = reinterpret_cast<CSprite2d_DrawRect_t>(gameBase + DRAW_RECT_OFFSET + 1);
    DrawPolyFn = reinterpret_cast<CSprite2d_Draw2DPolygon_t>(gameBase + DRAW_2D_POLYGON_OFFSET + 1);
    lastButtonTap = std::chrono::steady_clock::now() - std::chrono::seconds(10);
    buttonInitialized = true;
}

static bool isTouchInside(const CRect& r)
{
    const int count = GetNumTouches();
    for (int id = 0; id < count; ++id)
    {
        if (!IsTouchDown(id)) continue;
        CVector2D p{};
        GetTouchPosition(&p, id);
        if (p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom)
            return true;
    }
    return false;
}

static void drawLineDots(float x1, float y1, float x2, float y2, float thick, const CRGBA& c)
{
    const float dx = x2 - x1, dy = y2 - y1;
    const float len = std::sqrt(dx * dx + dy * dy);
    if (len < 0.5f) return;
    const float step = thick * 0.8f;               
    const int n = (int)(len / step) + 1;
    const float h = thick * 0.5f;
    for (int i = 0; i <= n; ++i)
    {
        const float t = (float)i / (float)n;
        const float x = x1 + dx * t, y = y1 + dy * t;
        drawRect(x - h, y - h, x + h, y + h, c);
    }
}

static void drawCheckMark(float cx, float cy, float s, const CRGBA& c)
{
    const float t = s * 0.12f;
    drawLineDots(cx - s * 0.28f, cy + s * 0.02f, cx - s * 0.08f, cy + s * 0.22f, t, c);
    drawLineDots(cx - s * 0.08f, cy + s * 0.22f, cx + s * 0.30f, cy - s * 0.22f, t, c);
}

static void drawCrossMark(float cx, float cy, float s, const CRGBA& c)
{
    const float t = s * 0.12f, k = s * 0.22f;
    drawLineDots(cx - k, cy - k, cx + k, cy + k, t, c);
    drawLineDots(cx + k, cy - k, cx - k, cy + k, t, c);
}

static void updatePreviewButtons()
{
    const float W = (float)RsGlobal.maximumWidth;
    const float H = (float)RsGlobal.maximumHeight;
    const float size = H * 0.14f;
    const float gap = size * 0.9f;
    const float cy = H * 0.80f;
    const float cxNo = W * 0.5f - gap, cxOk = W * 0.5f + gap;
    cancelBounds = CRect{cxNo - size * 0.5f, cy - size * 0.5f, cxNo + size * 0.5f, cy + size * 0.5f};
    confirmBounds = CRect{cxOk - size * 0.5f, cy - size * 0.5f, cxOk + size * 0.5f, cy + size * 0.5f};

    const bool okTouch = isTouchInside(confirmBounds);
    const bool noTouch = isTouchInside(cancelBounds);

    if (!previewOpenedThisFrame)
    {
        const auto now = std::chrono::steady_clock::now();
        const bool cooled = std::chrono::duration<float>(now - lastButtonTap).count() >= COOLDOWN_SECONDS;
        if (cooled && okTouch && !wasConfirmTouched)
        {
            lastButtonTap = now;
            previewConfirmed = true;
            previewActive = false;
        }
        else if (cooled && noTouch && !wasCancelTouched)
        {
            lastButtonTap = now;
            previewCancelled = true;
            previewActive = false;
        }
    }
    wasConfirmTouched = okTouch;
    wasCancelTouched = noTouch;
}

static void drawPreviewButtons()
{
    struct B { const CRect* r; bool ok; bool down; } btns[2] = {
        { &cancelBounds, false, wasCancelTouched },
        { &confirmBounds, true,  wasConfirmTouched },
    };
    for (const B& b : btns)
    {
        const float cx = (b.r->left + b.r->right) * 0.5f;
        const float cy = (b.r->top + b.r->bottom) * 0.5f;
        const float size = (b.r->right - b.r->left) * (b.down ? 0.94f : 1.0f);
        const CRGBA fill = b.ok ? CRGBA(39, 174, 96, 255) : CRGBA(214, 48, 49, 255);
        drawOctagon(cx + 2.0f, cy + 3.0f, size + 6.0f, CRGBA(0, 0, 0, 90));
        drawOctagon(cx, cy, size, CRGBA(12, 13, 15, 245));
        drawOctagon(cx, cy, size - 6.0f, CRGBA(235, 235, 235, 255));
        drawOctagon(cx, cy, size - 12.0f, fill);
        if (b.ok) drawCheckMark(cx, cy, size, CRGBA(255, 255, 255, 255));
        else      drawCrossMark(cx, cy, size, CRGBA(255, 255, 255, 255));
    }
}

static void drawWallPreview()
{
    if (!hasWallPreview) return;
    const WallGhost& g = wallPreview;

    RwV3d scr[8];
    bool ok[8];
    for (int i = 0; i < 8; ++i)
    {
        const float sw = (i & 1) ? 1.0f : -1.0f;
        const float st = (i & 2) ? 1.0f : -1.0f;
        const float sh = (i & 4) ? 1.0f : -1.0f;
        CVector w(g.cx + g.rx * g.halfW * sw + g.nx * g.halfT * st,
                  g.cy + g.ry * g.halfW * sw + g.ny * g.halfT * st,
                  g.cz + g.halfH * sh);
        float sx = 0.0f, sy = 0.0f;
        ok[i] = CSprite::CalcScreenCoors(w, &scr[i], &sx, &sy, true, true);
    }

    static const int edges[12][2] = {
        {0,1},{2,3},{4,5},{6,7},      
        {0,2},{1,3},{4,6},{5,7},      
        {0,4},{1,5},{2,6},{3,7}       
    };
    const float th = (float)RsGlobal.maximumHeight * 0.004f + 1.5f;
    for (const auto& e : edges)
        if (ok[e[0]] && ok[e[1]])
            drawLineDots(scr[e[0]].x, scr[e[0]].y, scr[e[1]].x, scr[e[1]].y, th, CRGBA(120, 220, 255, 235));
}

void UpdateWallButton()
{
    previewConfirmed = false;
    previewCancelled = false;
    previewOpenedThisFrame = false;
    buttonVisible = false;

    if (!buttonInitialized || !GetNumTouches || !IsTouchDown || !GetTouchPosition)
        return;

    CPlayerPed* player = FindPlayerPed(-1);
    if (!player || !player->m_matrix)
    {
        previewActive = false;
        wasButtonTouched = false;
        return;
    }

    if (previewActive)
    {
        updatePreviewButtons();
        wasButtonTouched = true;   
        return;
    }

    CVector anchor = player->GetPosition();
    const CVector right = player->GetRightDirection();
    anchor.x += right.x * 1.1f;
    anchor.y += right.y * 1.1f;
    anchor.z += 0.9f;

    RwV3d screen{};
    float sx = 0.0f, sy = 0.0f;
    if (!CSprite::CalcScreenCoors(anchor, &screen, &sx, &sy, true, true))
    {
        wasButtonTouched = false;
        return;
    }

    buttonBounds.left = screen.x - BUTTON_W * 0.5f;
    buttonBounds.top = screen.y - BUTTON_H * 0.5f;
    buttonBounds.right = screen.x + BUTTON_W * 0.5f;
    buttonBounds.bottom = screen.y + BUTTON_H * 0.5f;
    buttonVisible = true;

    const bool touching = isTouchInside(buttonBounds);
    if (touching && !wasButtonTouched)
    {
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<float>(now - lastButtonTap).count() >= COOLDOWN_SECONDS)
        {
            lastButtonTap = now;
            previewActive = true;           
            previewOpenedThisFrame = true;
            wasConfirmTouched = wasCancelTouched = false;
        }
    }
    wasButtonTouched = touching;
}

void DrawWallButton()
{
    if (!buttonInitialized) return;

    if (previewActive)
    {
        drawWallPreview();
        drawPreviewButtons();
        return;
    }
    if (!buttonVisible) return;

    const float cx = (buttonBounds.left + buttonBounds.right) * 0.5f;
    const float cy = (buttonBounds.top + buttonBounds.bottom) * 0.5f;
    const float s = wasButtonTouched ? 0.94f : 1.0f;
    const float outer = 66.0f * s, inner = 58.0f * s;

    drawOctagon(cx + 2.0f, cy + 3.0f, outer + 5.0f, CRGBA(0, 0, 0, 90));
    drawOctagon(cx, cy, outer, CRGBA(12, 13, 15, 245));
    drawOctagon(cx, cy, inner + 4.0f, CRGBA(225, 225, 225, 255));
    drawOctagon(cx, cy, inner, CRGBA(18, 19, 21, 255));
    drawBrickIcon(cx, cy, 38.0f * s, CRGBA(255, 255, 255, 255));
}

bool IsWallPreviewActive() { return previewActive; }
void SetWallPreviewActive(bool a) { previewActive = a; if (!a) hasWallPreview = false; }
void SetWallGhost(const WallGhost* g) { if (g) { wallPreview = *g; hasWallPreview = true; } else hasWallPreview = false; }
bool WasWallConfirmed() { return previewConfirmed; }
bool WasWallCancelled() { return previewCancelled; }
