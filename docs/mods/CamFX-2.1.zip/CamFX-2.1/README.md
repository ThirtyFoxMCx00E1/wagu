# CamFX (CameraFX 2.1)

Camera FOV effects for GTA San Andreas on Android, as an AML mod. Part of the TYFMC mods (MP, MLG, CamFX).
Based on the original SACamFX CLEO script (sprint and fall zoom); this native version adds parachute,
vehicle and weapon zoom and its own settings tab.

## Install

1. Needs AML (AndroidModLoader) and SAUtils.
2. Copy `bin/libCameraFX32.so` (32-bit game) or `bin/libCameraFX64.so` (64-bit game) into the AML mods folder.
3. Start the game. Settings are in Settings > CameraFX.

| What | Where |
|---|---|
| Settings | `Android/data/com.rockstargames.gtasa/files/TYFMC/TYFMC.CAMFX.ini` |
| Data (diagnostic.log) | `Android/data/com.rockstargames.gtasa/files/TYFMC/CamFX/` |

An older `configs/CameraFX.ini` and `files/CameraFX` folder are moved there on the first start.

## Effects

- Sprint zoom: FOV widens while sprinting (speed threshold, zoom-out / zoom-in time).
- Fall zoom: FOV widens during a long fall.
- Parachute, vehicle (follows speed) and weapon (assault rifles / rifles while aiming) zoom.
- From the original SACamFX script (2.1): Change FOV When Falling (`ChangeFovWhenFall`),
  Fall Zoom Only When Sky Diving (`ParaOnly`, only while the FALL_skyDive pose plays) and
  Drunk Effect When Falling (`DrunkEffect`, the screen wobble rises while falling and goes away on landing).
- Smooth blend transitions, 8 languages.

## Changes in 2.1

- 64-bit fix: SAUtils writes a full 8-byte word back for every script output value on arm64, which
  overwrote the variable next to each 4-byte int / float. All outputs now go into 8-byte slots.
  The old SIGSEGV catch-and-skip guard is removed (it only hid the problem).
- The ini is `files/TYFMC/TYFMC.CAMFX.ini`, the data folder `files/TYFMC/CamFX`.
- The SACamFX options above, and the language choice is saved.

## Build

```
NDK=/path/to/android-ndk-r30 ./build.sh
```
Output: `bin/libCameraFX32.so` (armeabi-v7a) and `bin/libCameraFX64.so` (arm64-v8a).

## Files

- `jni/` - source (main.cpp, tyfmc.h, AML mod headers)
- `original/` - the original SACamFX CLEO script and its ini, for reference

Author: Senji. Original SACamFX CLEO script by its respective author.
