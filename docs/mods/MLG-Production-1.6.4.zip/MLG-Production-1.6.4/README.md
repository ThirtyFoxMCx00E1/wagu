# MLG Production

An AML mod for GTA San Andreas on Android that adds a movie-making panel: a top-right menu with the MLG wolf logo (a shine sweeps over the title) and eight flat buttons, plus a bottom recording timeline.

- `bin/libMLG32.so` for 32-bit (armeabi-v7a)
- `bin/libMLG64.so` for 64-bit (arm64-v8a)

## Install

1. Copy the `.so` that matches your game (or both) into your AML mods folder.
2. Start the game. Recordings and animations are saved to `<game data>/TYFMC/MLG/` (the TYFMC folder holds the MP, MLG and CamFX folders), and the settings to `<game data>/TYFMC/TYFMC.MLG.ini`. An older `MLG` folder and `mlg.cfg` are moved there by themselves.

## Changes

- 1.6.1: fixes the game staying on a black screen at start (MLG 1.6 stopped the game right after it loaded, by a bad log call). Settings and recordings are kept.
- 1.6.2: recording while driving: the folded timeline bar at the top now has Record / Stop, so you can record without opening the timeline. Getting in a car right after pressing Record starts the take again for the car.
- 1.6.4: the original MLG textures are back (the wolf logo photo and the eight photo button strips from 1.6.2), only now they are still: no drifting logo, no glowing eyes, no embers, no colour cycling border, no panning buttons. The only animation is the light sweep over the chrome "MLG PRODUCTION" letters.
- 1.6.3: new flat look. The wolf logo and the eight button textures are redrawn as clean flat art (no photos), and nothing on them moves any more: the only animation left is the shine that sweeps over the "MLG PRODUCTION" title.

## Usage

- Tap the "Tools menu" tab in the top-left corner to show or hide the MLG Production panel in the top-right corner.
- The panel has eight buttons, all unlocked: Free Cam, Entity Tools, Ped Tools, Chroma Key, Scene, Weather & Time, Settings and Recording. Each tool opens its own window; move it by its title bar and close it with the red X.
- Free Cam (Camera tab): three modes (Free fly, Orbit target, Follow target). The stick in the bottom-left corner moves the camera, Up / Down move it vertically (they tilt the camera in Orbit mode), and sliding anywhere else on the screen looks around. Speed goes from 0.25x to 16x, look sensitivity from 0.5x to 2x. "Smooth movement" eases the camera in and out when you start or stop moving or looking. "Look at target" keeps the target ped in the middle of the screen. Optional field of view (FOV), "Hold player at the camera" (keeps the world around the camera loaded), "Move with game speed" (slows down with slow motion), "Back to target" and "Player to camera". Tap "Free Cam - Exit" at the top of the screen to leave.
- Free Cam (Arrows tab): camera paths made of 3D arrows. Fly to a spot, look where the shot should look, and tap "Add arrow". Each arrow shows the camera's position and direction in the world, numbered, and a line (the path) joins them. Dots on the path are a quarter second apart, so you can see where the camera slows down. "Move" picks how the camera travels between arrows: Ease in-out (default; a straight move that starts and stops slowly at every arrow, like the camera on a server connection screen), Smooth + ease, Smooth path (a curve through all arrows) or Linear. "New arrow" places the next arrow 1 to 10 s after the last one, or at the timeline playhead. Tap an arrow in the world (or Prev / Next) to select it; "Update" moves it to the current camera, "Go to arrow" puts the Free Cam on it, "Delete" removes it. "Play path" plays the camera move. Arrows are the timeline's camera keys, so they also play with a take and are saved with it.
- Ped Tools (ped selection list): every ped within 150 m, nearest first. Tap one to select it; the selection becomes the target for Entity Tools (bone posing and animations), Free Cam (Orbit / Follow), Chroma Key and Scene triggers. Bring here, Go to ped, Face me, Freeze, Hide, Stand still and Delete ped work on the selection. "Takes and animations play on this ped" replays a recorded take on the selected ped instead of the player. Spawn any ped model id in front of you; "Remove all" deletes the peds you spawned.
- Chroma Key: a solid backdrop (green, blue, black, white or pink) behind the target ped, or at a fixed distance from the camera. Everything farther away than the backdrop is covered, so the actor and the ground in front stay visible. The game HUD hides while it is on (optional).
- Scene: game speed (0.1x to 2x), ped and traffic density, hide or freeze the player, clear the area, and triggers. A trigger is placed at your position; when the target ped walks into it, it plays the take, starts recording, stops, plays the animation or toggles slow motion. Tap a trigger's name to change its action, and -/+ to change its size.
- Weather & Time: all 23 weathers, back to the game's weather, the time of day (-1 h, +1 h, -10 min, +10 min, Dawn, Noon, Sunset, Night) and Freeze time.
- Entity Tools (animation making): tap a bone on the body figure, slide X / Y / Z to bend it (Drag power changes the speed), then Add a key. Move the red playhead, pose again and add more keys; Play blends between them. "+ Full Body" keys every bone at once, "Grab From time" + "Paste" copies a pose to another time, Mirror copies a bone to the other side. The Anim tab sets the clip length, loop, save/load (TYFMC/MLG/anims/anim_N.mla) and "Play with Recording", which plays the clip in sync with a take. The Misc tab has Position and Orientation tracks that move the player while the clip plays.
- Entity Tools also opens the Recording timeline next to the Manipulator, like the animation player in PumaStudio. The timeline has the take bar ("0: PED_n" or "0: CAR_model") and an Anim track ("1: Anim PED_n") showing the clip length and its keys. Tap the bone icon on the Anim track to play the clip with the timeline; dragging the ruler shows the pose at that time. The status bar shows Zoom, Play (playback speed, tap to change), Game (game speed, tap to change) and Follow Cursor.
- While you drive, the timeline folds into a small bar at the top so it does not cover the car controls (Settings > Fold the timeline while driving). Tap "Show" on the bar to open it anyway.
- Timeline: Record captures the player (on foot or in a car) at 30 fps after a 3 second countdown. Play replays the take. Use +Key, Delete, Prev and Next to add camera keys; the camera moves along a smooth path through them.
- Recording keeps going when you close the timeline or the menu. A small "REC" bar appears at the top of the screen; tap it to stop.
- Hold anywhere on the menu and slide to move it. The Manipulator and the animation window move by their title bars. Hold and slide the free part of the timeline's top bar (the dots) to move the timeline. Show > Reset menu positions puts both back.
- Settings (or Show > Size) switches between Small, Medium, Large (default) and Extra large. The sizes are bigger than the PC original because phone screens are smaller.
- The game HUD is hidden while the menu is open (Show > Hide game HUD while menu is open).
- The File, Show, Playback and Recording menus hold save/load, loop, speed and clean screen options. Takes are saved as `TYFMC/MLG/recordings/take_N.mlg`.

## Build

```
NDK=/path/to/android-ndk-r30 ./build.sh
```

## Credits

The panel and timeline layout was inspired by [PumaStudio by ZZPuma](https://www.patreon.com/ZZPuma/posts/pumastudio-v0-4-135745308) ([blog](https://zzpumazone.blogspot.com/)). The 1.3 tool set follows the PumaStudio 0.2 feature list (Free Cam, Ped Selection List, Chroma Key, Triggers). No PumaStudio code or assets are included; the wolf logo and button textures were generated for this project. Built with AML headers, Dear ImGui and stb_image.
