MP moderators (3.35.2)
======================
Moderators are NOT the admin key (admin.txt).

3.35.2: the MP moderator key. Put Android/data/com.rockstargames.gtasa/files/TYFMC/MP/moderator.txt
(the MP moderator key on one line, get it from the MP owner) on your phone and you are "[MOD] your name"
on every updated MP server, with any name - no server list needed.

Or a server owner picks their own moderators:

Server owner (VPS / Termux / Oracle): make moderator.txt next to mp_server, one line per moderator:
    # name  key (8+ characters, no spaces)
    Juan   juan-secret-key-123
  (or mp_server ... --mods /path/to/moderator.txt; a server hosted in the game reads
   Android/data/com.rockstargames.gtasa/files/TYFMC/MP/moderators_server.txt)

Moderator (phone): put the same key in Android/data/com.rockstargames.gtasa/files/TYFMC/MP/moderator.txt
(just the key on one line) and join with that player name. You get "[MOD] name" in the name tag,
chat and kill feed, and can kick / mute players and switch cheats on that server (ban = admin only).

3.40.1: the name Trunk is reserved for moderators (like SENJI for the admin).
Only a phone with moderator.txt holding an MP moderator key (or a key the server owner
listed for Trunk: "Trunk  MOD:<key>" or "Trunk  <key>") can join as Trunk. It shows as
"[MOD] Trunk" in the name tag, chat, kill feed and player list, with the moderator permissions
on the 4 default servers. Without the key the name box says "Reserved (moderator)" and every
3.40.1 server refuses the join. Spaces / line breaks around the key don't matter any more.
