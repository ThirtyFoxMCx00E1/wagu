MP 3.23.6 - admin key (SENJI)

The admin key is secret, so it is NOT inside this public package.
3.23.6 has a NEW admin key. Put administrator.txt (one line: the new admin key) here:
  /storage/emulated/0/Android/data/com.rockstargames.gtasa/files/MP/administrator.txt
  (some phones: /storage/emulated/0/Android_unprotected/data/com.rockstargames.gtasa/files/MP/)
Keep your old key file next to it, renamed to admin.txt: MP 3.23.6 sends the new key first and the
old one only to a server that has not been updated yet.

"This server refused your admin key" = that SERVER runs an old mp_server. Update it:
  24/7 HiveMQ server:  curl -fsSL https://raw.githubusercontent.com/ThirtyFoxMCx00E1/HiveMQ/main/update.sh | sudo bash
                       (it also updates by itself within 10 min, after you ran that once)
  Termux phone server: mp-server update
  Phone host:          that player installs MP 3.23.6
