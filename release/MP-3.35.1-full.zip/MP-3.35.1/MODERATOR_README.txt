MP moderators (3.35)
====================
Moderators are NOT the admin key (admin.txt). Every server owner picks their own.

Server owner (VPS / Termux / Oracle): make moderator.txt next to mp_server, one line per moderator:
    # name  key (8+ characters, no spaces)
    Juan   juan-secret-key-123
  (or mp_server ... --mods /path/to/moderator.txt; a server hosted in the game reads
   Android/data/com.rockstargames.gtasa/files/MP/moderators_server.txt)

Moderator (phone): put the same key in Android/data/com.rockstargames.gtasa/files/MP/moderator.txt
(just the key on one line) and join with that player name. You get "[MOD] name" in the name tag,
chat and kill feed, and can kick / mute players and switch cheats on that server (ban = admin only).
